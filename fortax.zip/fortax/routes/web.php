<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/logout', 'AccessController@logout');
Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');


Route::group(['middleware'=>['auth']],function(){
	
	// client product operation

	Route::match(['get','post'],'/home/addProduct','ProductController@addProduct');
	Route::match(['get','post'],'/home/viewProduct','ProductController@viewProduct');
	Route::match(['get','post'],'/home/deleteProduct/{id}','ProductController@deleteProduct');
	Route::match(['get','post'],'/home/editProduct/{id}','ProductController@editProduct');
	Route::match(['get','post'],'/home/createBill','invoiceController@createBill');
    Route::get('searchajax', ['as'=>'searchajax','uses'=>'invoiceController@searchResponse']);

	//client product operation ends here 

	// AdminController

	// crawler

	Route::match(['get','post'],'/home/addCrawler','AdminController@addCrawler');
	Route::match(['get','post'],'/home/viewCrawler','AdminController@viewCrawler');
	Route::match(['get','post'],'/home/deleteCrawler/{id}','AdminController@deleteCrawler');
	Route::match(['get','post'],'/home/editCrawler/{id}','AdminController@editCrawler');

	// Rocket

	Route::match(['get','post'],'/home/addRocket','AdminController@addRocket');
	Route::match(['get','post'],'/home/viewRocket','AdminController@viewRocket');
	Route::match(['get','post'],'/home/deleteRocket/{id}','AdminController@deleteRocket');
	Route::match(['get','post'],'/home/editRocket/{id}','AdminController@editRocket');

	// Client

	Route::match(['get','post'],'/Admin/addClient','AdminController@addClient');
	Route::match(['get','post'],'/Admin/viewClient','AdminController@viewClient');
	Route::match(['get','post'],'/Admin/deleteClient/{id}','AdminController@deleteClient');
	Route::match(['get','post'],'/Admin/editClient/{id}','AdminController@editClient');

	//admin controller end

	// Crawlercontroller

	// client

	Route::match(['get','post'],'/Crawler/addClient','CrawlerController@addClient');
	Route::match(['get','post'],'/Crawler/viewClient','CrawlerController@viewClient');
	// Route::match(['get','post'],'/Crawler/deleteClient/{id}','CrawlerController@deleteClient');
	Route::match(['get','post'],'/Crawler/editClient/{id}','CrawlerController@editClient');
});
