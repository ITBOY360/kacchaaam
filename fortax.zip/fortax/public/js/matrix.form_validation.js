$(document).ready(function(){
	
	$("#current_pwd").keyup(function(){
		var current_pwd = $("#current_pwd").val();

		$.ajax({
			type:'get',
			url: '/admin/check-pwd',
			data:{current_pwd:current_pwd},

			success:function(resp){

				// alert('true');
				if(resp=='false'){
					$("#chkPwd").html("<font color='red'>the current password you entered is incorrect. </font>");
				}else if(resp=='true'){
					$("#chkPwd").html("<font color='green'>the current password you entered is correct, please set new password. </font>");
				}

			},
			error:function(){

				alert("error");
			}
		});
	});
	
	$('input[type=checkbox],input[type=radio],input[type=file]').uniform();
	
	$('select').select2();
	
	// Form Validation
    $("#basic_validate").validate({
		rules:{
			required:{
				required:true
			},
			email:{
				required:true,
				email: true
			},
			date:{
				required:true,
				date: true
			},
			url:{
				required:true,
				url: true
			}
		},
		errorClass: "help-inline",
		errorElement: "span",
		highlight:function(element, errorClass, validClass) {
			$(element).parents('.control-group').addClass('error');
		},
		unhighlight: function(element, errorClass, validClass) {
			$(element).parents('.control-group').removeClass('error');
			$(element).parents('.control-group').addClass('success');
		}
	});
	//add catogery  validator
	$("#add_catogery").validate({
		rules:{

			catogery_name:{
				required:true,
			},
			description:{
				required:true,			},
			url:{
				required:true,
			}
		},
		errorClass: "help-inline",
		errorElement: "span",
		highlight:function(element, errorClass, validClass) {
			$(element).parents('.control-group').addClass('error');
		},
		unhighlight: function(element, errorClass, validClass) {
			$(element).parents('.control-group').removeClass('error');
			$(element).parents('.control-group').addClass('success');
		}
	});
	$("#number_validate").validate({
		rules:{
			min:{
				required: true,
				min:10
			},
			max:{
				required:true,
				max:24
			},
			number:{
				required:true,
				number:true
			}
		},
		errorClass: "help-inline",
		errorElement: "span",
		highlight:function(element, errorClass, validClass) {
			$(element).parents('.control-group').addClass('error');
		},
		unhighlight: function(element, errorClass, validClass) {
			$(element).parents('.control-group').removeClass('error');
			$(element).parents('.control-group').addClass('success');
		}
	});
	
	$("#password_validate").validate({
		rules:{
			current_pwd:{
				required: true,
				minlength:8,
				maxlength:20
			},
			new_pwd:{
				required: true,
				minlength:8,
				maxlength:20
			},
			pwd_repeat:{
				required:true,
				minlength:8,
				maxlength:20,
				equalTo:"#new_pwd"
			}
		},
		errorClass: "help-inline",
		errorElement: "span",
		highlight:function(element, errorClass, validClass) {
			$(element).parents('.control-group').addClass('error');
		},
		unhighlight: function(element, errorClass, validClass) {
			$(element).parents('.control-group').removeClass('error');
			$(element).parents('.control-group').addClass('success');
		}
	});

	// $(".delBtn ").click(function(){
	// 	if(confirm('are you sure you  want to deleate selection permanently')){
	// 		return true;
	// 	}
	// 	return false;
	// });

	$(".deleteRecord").click(function(){
		var id = $(this).attr('rel');
		var deleteFunction = $(this).attr('rel1');
		swal({
				title: 'Are you Sure ?',
				text: "you won't be able to revert this",
				type: "warning",
				showCancelButton: true, 
				confirmButtonColor: '#3085d6',
				canceButtonColor: '#d33',
				confirmButtonText: 'yes ! delete it !!',
				canceButtonText: 'No !! cancel it ',
				confirmButtonClass :'btn btn-success',
				canceButtonClass: 'btn btn-danger',
				buttonStyling: false,
				reverseButton: false,
			},
				function(){
					window.location.href="/home/"+deleteFunction+'/'+id;
			});

	});
});











				
			