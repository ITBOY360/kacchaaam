<!--sidebar-menu-->
<div id="sidebar"><a href="{{ url('/home') }}" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="{{ url('/home') }}"><i class="icon  icon-dashboard"></i> <span>Dashboard</span></a> </li>
    <li><a href="{{ url('/Crawler/addClient') }}"><i class="icon icon-plus"></i><span>Add Client</span></a> </li>
    <li><a href="{{ url('/Crawler/viewClient') }}"><i class="icon icon-list"></i><span>View Client</span></a> </li>
   {{--  <li><a href="{{ url('/home') }}"><span></span></a> </li> --}}
  </ul>
</div>
<!--sidebar-menu--> 