<!--sidebar-menu-->
<div id="sidebar"><a href="{{ url('/home') }}" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="{{ url('/home') }}"><i class="icon  icon-dashboard"></i> <span>Dashboard</span></a> 
      <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Crawler</span> 
      	<span class="label label-important">2</span></a>
      <ul>
        <li><a href="{{ url('/home/addCrawler') }}">Add Crawler</a></li>
        <li><a href="{{ url('/home/viewCrawler') }}">View Crawler</a></li>
        {{-- <li></li> --}}
      </ul>
    </li>
     <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Rocket</span> 
      	<span class="label label-important">2</span></a>
      <ul>
        <li><a href="{{ url('/home/addRocket') }}">Add Rocket</a></li>
        <li><a href="{{ url('/home/viewRocket') }}">View Rocket</a></li>
        {{-- <li></li> --}}
      </ul>
    </li> 
      <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Client</span> 
      	<span class="label label-important">2</span></a>
      <ul>
        <li><a href="{{ url('/Admin/addClient') }}">Add Client</a></li>
        <li><a href="{{ url('/Admin/viewClient') }}">View Client</a></li>
        {{-- <li></li> --}}
      </ul>
    </li>
   {{--  <li><a href="{{ url('/home') }}"><span></span></a> </li> --}}
  </ul>
</div>
<!--sidebar-menu--> 