@extends('layouts.Crawler_layout.Crawler_design')
@section('title','View Client')
@section('content')


<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="{{ url('/home') }}" title="Go to Home" class="tip-bottom">
      <i class="icon-home"></i> Home</a> <a href="#" class="current">Client</a> </div>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <h3>Avilable Client</h3><hr>
        @if(Session::has('flash_message_success'))
          <div class="alert alert-success alert-dismissible animated shake">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <b>{!! Session('flash_message_success') !!} </b>
          </div>        
        @endif 
        <div class="widget-box"> 
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <a href="{{ url('/Crawler/addClient') }}" class="btn btn-success pull-right">Add more Client</a>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered  data-table" id="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Mobile Number</th>
                  <th>Email</th>
                  <th>Shop Name</th>
                  <th>Zone</th>
                  <th>State</th>
                  <th>Address</th>
                  <th>ACtion</th>
                </tr>
              </thead>
              <tbody>
                @foreach($Client as $key)
                <tr class="gradeX">
                  <td><b>{{ $key->fname }} {{ $key->lname }}</b></td>
                  <td><b>{{ $key->Mobile_number }}</b></td>
                  <td><b>{{ $key->email }}</b></td>
                  <td><b>{{ $key->Bussiness_name }}</b></td>
                  <td><b>{{ $key->zone }} </b></td>
                  <td><b>{{ $key->state }} <b></b></b></td>
                  <td><b>{{ $key->Address }}</b></td>
                  <td class="center">
                    <a href="#view{{ $key->id }}" data-toggle="modal"  class="btn btn-success btn-mini">View</a>
                    <a href="{{ url('/Crawler/editClient/'.$key->id ) }}" class="btn btn-primary btn-mini">Edit</a>
                   {{--  <a  rel="{{ $key->id }}"  rel1="deleteClient" href="javascript: " class="deleteRecord btn btn-danger btn-mini">Delete</a> --}}
                  </td> 
                </tr>
                 <div id="view{{ $key->id }}" class="modal hide animated bounce ">
                      <div class="modal-header">
                        <button data-dismiss="modal" class="close" type="button">×</button>
                        <h3>{{ $key->fname }} {{ $key->lname }} Compleate Details</h3>
                      </div>
                      <div class="modal-body">
                        <div class="container-fluid">
                          <div class="row-fluid">
                      <div class="span6 pull-left">              
                             <ul>
                                <li><strong>Name</strong></li>
                                <li><strong>Mobile Number</strong></li>
                                <li><strong>Email</strong></li>
                                <li><strong>Business Name</strong></li>
                                <li><strong>GST User Name</strong></li>
                                <li><strong>GST User Password</strong></li>
                                <li><strong>GST</strong></li>
                                <li><strong>Zone</strong></li>
                                <li><strong>State</strong></li>
                                <li><strong>Bank A/C number</strong></li>
                                <li><strong>Aadhar Number</strong></li>
                                <li><strong>Refral_id</strong></li> 
                                <li><strong>PAN</strong></li>
                                <li><strong>Address</strong></li>
                              </ul>
                            </div>
                            <div class="clear-fix"></div>
                        <div class="span6 pull-right">              
                             <ul>
                                <li class="red">{{ $key->fname }} {{ $key->lname }}</li>
                                <li class="red">{{ $key->Mobile_number }}</li>
                                <li class="red">{{ $key->email }}</li>
                                <li class="red">{{ $key->Bussiness_name }}</li> 
                                <li class="red">{{ $key->UserName_gst }}</li> 
                                <li class="red">{{ $key->Password_gst }}</li>
                                <li class="red">{{ $key->GST }}</li>
                                <li class="red">{{ $key->zone }}</li>
                                <li class="red">{{ $key->state }}</li>
                                <li class="red">{{ $key->Account_number }}</li>
                                <li class="red">{{ $key->aadhar }}</li>
                                <li class="red">{{ $key->refral_id }}</li>
                                <li class="red">{{ $key->PAN }}</li>
                                <li class="red">{{ $key->Address }}</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
        
      </div>
    </div>       
  </div>
</div>
@endsection