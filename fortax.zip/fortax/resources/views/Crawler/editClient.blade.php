@extends('layouts.Crawler_layout.Crawler_design')
@section('title','edit Client')
@section('content')
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="{{ url('/home') }}" title="Go to Home" class="tip-bottom">
    	<i class="icon-home"></i> Home</a> <a href="{{ url('/Crawler/viewClient') }}">Client</a> <a href="#" class="current">Edit Client</a> </div>
  </div>
  <div class="container-fluid">    
    <hr>
       @if(Session::has('flash_message_success'))
                    <div class="alert alert-success alert-dismissible animated shake">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                       <b>{!! Session('flash_message_success') !!} </b>
                    </div>        
            @endif

          @if(Session::has('flash_message_error'))
                    <div class="alert alert-danger alert-dismissible animated shake">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                       <b>{!! Session('flash_message_error') !!} </b>
                    </div>        
            @endif     
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
            <h5>Edit Client</h5>
          </div>
          <div class="widget-content nopadding">
            <form class="form-horizontal" method="post" action="{{ url('/Crawler/editClient/'.$ClientDetails->id) }}" name="editClient" id="editClient" enctype="multipart/form-data">
              @csrf
              <input type="hidden" name="refral_id" id="refral_id" value="Admin">
              <div class="control-group">
                <label class="control-label">First Name</label>
                <div class="controls">
                  <input type="text" name="fname" id="fname" value="{{ $ClientDetails->fname }}" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Last Name</label>
                <div class="controls">
                  <input type="text" name="lname" id="lname" value="{{ $ClientDetails->lname }}" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Mobile Number</label>
                <div class="controls">
                  <input type="number" name="Mobile_number" id="Mobile_number" value="{{ $ClientDetails->Mobile_number }}" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">EMail</label>
                <div class="controls">
                  <input type="email" name="email" id="email" value="{{ $ClientDetails->email }}" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Password</label>
                <div class="controls">
                  <input type="password" name="password" id="password" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Bank Account Number</label>
                <div class="controls">
                  <input type="number" name="Account_number" id="Account_number" value="{{ $ClientDetails->Account_number }}" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Aadhar Number</label>
                <div class="controls">
                  <input type="number" name="aadhar" id="aadhar" value="{{ $ClientDetails->aadhar }}" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">PAN</label>
                <div class="controls">
                  <input type="text" name="PAN" id="PAN" value="{{ $ClientDetails->PAN }}" required>
                </div>
              </div>

                 <div class="control-group">
                <label class="control-label">Shop Name</label>
                <div class="controls">
                  <input type="text" name="Bussiness_name" id="Bussiness_name" value="{{ $ClientDetails->Bussiness_name }}" required>
                </div>
              </div> 

               <div class="control-group">
                <label class="control-label">GST User Name</label>
                <div class="controls">
                  <input type="text" name="UserName_gst" id="UserName_gst" value="{{ $ClientDetails->UserName_gst }}" required>
                </div>
              </div>  

              <div class="control-group">
                <label class="control-label">GST User Password</label>
                <div class="controls">
                  <input type="text" name="Password_gst" id="Password_gst" value="{{ $ClientDetails->Password_gst }}" required>
                </div>
              </div>

              <div class="control-group">
                <label class="control-label">GST Number</label>
                <div class="controls">
                  <input type="text" name="GST" id="GST" value="{{ $ClientDetails->GST }}" required>
                </div>
              </div>

              <div class="control-group">
                <label class="control-label">Location</label>
                <div class="controls">
                  <input type="text" name="zone" id="zone" value="{{ $ClientDetails->zone }}" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">State</label>
                <div class="controls">
                  <input type="text" name="state" id="state" value="{{ $ClientDetails->state }}">
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Address</label>
                <div class="controls">
                  <textarea name="Address" id="Address" required>{{ $ClientDetails->Address }}</textarea>
                </div>
              </div>

              <div class="form-actions">
                <input type="submit" value="Edit Client" class="btn btn-success">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection