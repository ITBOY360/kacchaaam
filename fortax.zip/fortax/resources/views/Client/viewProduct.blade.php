@extends('layouts.Client_layout.client_design')
@section('title','View Product')
@section('content')


<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="{{ url('/home') }}" title="Go to Home" class="tip-bottom">
      <i class="icon-home"></i> Home</a> <a href="#" class="current">product</a> </div>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <h3>Avilable product in Shop</h3><hr>
        @if(Session::has('flash_message_success'))
          <div class="alert alert-success alert-dismissible animated shake">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <b class="centertxt">{!! Session('flash_message_success') !!} </b>
          </div>        
        @endif 
        <div class="widget-box"> 
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <a href="{{ url('/home/addProduct') }}" class="btn btn-success pull-right">Add more product</a>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered  data-table" id="data-table">
              <thead>
                <tr>
                  <th>Product code</th>
                  <th>Product Name</th>
                  <th>Purchase Amount</th>
                  <th>Sales Amount</th>
                  <th>Stock Quantity</th>
                  <th>HSN</th>
                  <th>GST</th>
                  <th>ACtion</th>
                </tr>
              </thead>
              <tbody>
                @foreach($product as $key)
                <tr class="gradeX">
                  <td><b class="centertxt">{{ $key->product_code }}</b></td>
                  <td><b class="centertxt">{{ $key->product_name }}</b></td>
                  <td><b class="centertxt">{{ $key->purchase_amt }} Rs</b></td>
                  <td><b class="centertxt">{{ $key->sales_amt }} Rs</b></td>
                  <td><b class="centertxt">{{ $key->Stock_qty }}</b></td>
                  <td><b class="centertxt">{{ $key->HSN }} <b></b></b></td>
                   <td><b class="centertxt">{{ $key->GST }} <b>Rs</b></b></td>
                  <td class="center">
                    <a href="{{ url('/home/editProduct/'.$key->id ) }}" class="btn btn-primary btn-mini">Edit</a>
                    <a  rel="{{ $key->id }}"  rel1="deleteProduct" href="javascript: " class="deleteRecord btn btn-danger btn-mini">Delete</a>
                  </td> 
                </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>       
  </div>
</div>
@endsection