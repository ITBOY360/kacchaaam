 <!DOCTYPE html>
<html lang="en">
<head>
  <title>Create Invoice</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <!----------------------------------------------------------------------------------------------------------->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <!------------------------------------------------------------------------------------------------------------>
  <style type="text/css">
  	body{
  		background-color: #C0C0C0;
  	}
  	.container-fluid{
  		padding-top:5px;
  		padding-bottom:5px;
  		background-color:white;
  		border: 1px solid black;
  		border-radius:5px;
      max-width: 100%;
  	}
  	.title{
  		color:#c1682b ;
  		padding-top:10px;
  		text-align: center;
  	}
  	.center{
  		text-align: center;
  	}

  </style>
</head>
<body>

<div class="container-fluid">
 	<div class="col-lg-12"><h3 class="title">{{ Auth::user()->Bussiness_name }}</h3></div><hr>
 	<div class="row">
	 	 <div class="col-lg-6">
	 	 	<strong>INOVICE N/O -</strong> 25639875 <br/>
	 	 	<strong>GST  - </strong>{{ Auth::user()->GST }}<br/>
	 	 	<strong>DATE/TIME - </strong>{{ date('Y-m-d') }}/{{ date('H:i:s') }}<br/>
	 	 </div>
	 	 <div class="col-lg-6">
	 	 	<div  class="float-right"><strong>Shop Address</strong><br>{{ Auth::user()->Address }} </div>
	 	 </div>
 	</div>
 	<hr>
 	<div class="row">
 	  <div class="col-lg-12">
 	  	<form name="inovoice" id="inovoice" action="{{ url('/home/createBill') }}">

    		<div class="form-group float-left" style="width:50%;">
		      {{-- <label for="email">Client Name</label> --}}
		      <input type="email" class="form-control" id="email" placeholder="Enter Client Name" name="email">
		    </div>

		    <div class="form-group float-float-left" style="width:50%;">
		      {{-- <label for="pwd">Client Number</label> --}}
		      <input type="password" class="form-control" id="pwd" placeholder="Enter Client Mobile Number" name="pswd">
		    </div>

		     <div class="form-group float-right" style="width:48%;margin-top:-100px;">
		      {{-- <label for="pwd">Client Address</label> --}}
		      <textarea name="Client_address" class="form-control" placeholder="Enter Client Address"></textarea>
		    </div>
        <hr>

         <div class="control-group row-fluid">
            <div class="controls span12 ">
              <div class="field_wrapper">
                <div>
                   <input type="text" name="product_code[]" id="product_code" data-type="product_code" placeholder="product_code" required  />
                   <input type="text" name="product_name[]" id="product_name" data-type="product_name" placeholder="product_name" required  />
                   <input type="text" name="product_Price[]" id="product_Price" placeholder="Price"  style="width:90px;" required/>
                   <input type="text" name="GST_on_product[]" placeholder="GST_on_product" id="GST_on_product"  required/>
                   <input type="text" name="Qty[]" id="Qty" placeholder="Quantity" required />
                   <input type="text" name="Total[]" id="Total" placeholder="Total" required  />
                   <a href="javascript:void(0);" class="add_button btn " title="Add field">add</a>
                 </div>
                </div>
              </div>
            </div>
		    <a href="{{ url('/home') }}" class="btn btn-danger">Cancel</a>
		    <button type="submit" class="btn btn-primary">Create Inovice</button>
 	  	</form>
 	  </div>
 	</div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
    var maxField = 100; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = '<div><input type="text" name="product_code[]" id="product_code" data-type="product_code" placeholder="product_code" required  /> <input type="text" name="product_name[]" id="product_name" data-type="product_name" class=" autocomplete_txt" placeholder="product_name" required /> <input type="text" name="product_Price[]" id="product_Price" placeholder="Price" required style="width:90px;" /> <input type="text" name="GST_on_product[]" placeholder="GST_on_product" id="GST_on_product" required /> <input type="text" name="Qty[]" id="Qty" placeholder="Quantity" required /> <input type="text" name="Total[]" id="Total" placeholder="Total"required  /><a href="javascript:void(0);" class="remove_button btn " title="Add field">Remove</a></div>';
                     //New input field html 
    var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});
</script>
 {{--  <datalist id="product">
     @foreach($product as $key)
       <option value="{{ $key->product_code }}">{{ $key->product_name }}</option>
     @endforeach
   </datalist> --}}
</body>
</html> 