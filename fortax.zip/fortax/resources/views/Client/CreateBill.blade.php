    <!DOCTYPE html>
    <html>
    <head>
        <title>Create Inovoice</title>
        <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
        <script src="http://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
        <style type="text/css">
    body{
      background-color: #C0C0C0;
    }
    .clx{
      height:5px;
    }
    .container{
      padding-top:5px;
      padding-bottom:5px;
      background-color:white;
      border-radius:5px;
      
    }
    .title{
      color:#c1682b ;
      padding-top:10px;
      text-align: center;
    }
    .center{
      text-align: center;
    }
    .float-right{
      float: right;
      padding: 5px 5px;
    }
    .spc{
      max-width: 120px;
    }
  </style>
    </head>
    <body>
    <div class="clx"></div>
    <div class="container">
           <div class="col-lg-12"><h3 class="title">{{ Auth::user()->Bussiness_name }}</h3><hr></div>
            <div class="row">
               <div class="col-lg-6">
                <strong>INOVICE N/O -</strong> {{ date('YmdHis') }}<br/>
                <strong>GST  - </strong>{{ Auth::user()->GST }}<br/>
                <strong>DATE/TIME - </strong>{{ date('Y-m-d') }} / {{ date('H:i:s') }}<br/>
               </div>
               <div class="col-lg-6">
                <div  class="float-right"><strong>Shop Address</strong><br>{{ Auth::user()->Address }} </div>
               </div>
          </div><hr>
      <form action="{{url('/home/createBill')}}" method="post">
        @csrf
        <div class="form-group" >
          <input type="text" class="form-control" id="cname" placeholder="Enter Client Name" name="cname">
        </div>

        <div class="form-group" >
            <input type="tel" class="form-control" id="mobile" placeholder="Enter Client Mobile Number" name="pswd">
        </div>
        <div class="form-group" >
            <input type="email" class="form-control" id="mobile" placeholder="Enter Client email" name="pswd">
        </div>

         <div class="form-group" >
          <textarea name="Client_address" class="form-control" placeholder="Enter Client Address"></textarea>
        </div>
        <hr>
        <table class="table table-bordered">
          <tr>
              <th><input class='check_all' type='checkbox' onclick="select_all()"/></th>
              <th>S.no</th>
              <th>Product Code</th>
              <th>Product Name</th>
              <th>Sales Price</th>
              <th>HSN</th>
              <th>GST+CST</th>
              <th>TAX Amoust</th>
              <th>Quantity</th>
              <th>Total</th>
          </tr>
          <tr>
              <td><input type='checkbox' class='chkbox'/></td>
              <td><span id='sn'>1.</span></td>
              <td><input class="form-control autocomplete_txt" type='text' data-type="productCode" id='productCode_1' name='productCode[]'/></td>
              <td><input class="form-control autocomplete_txt" type='text' data-type="productName" id='productName_1' name='productName[]'/> </td>
              <td><input class="form-control autocomplete_txt" type='text' id='price_1'  name='price[]' disabled></td>
              <td><input class="form-control autocomplete_txt" type='text'  id='HSN_1' name='HSN[]' disabled/> </td>
              <td><input class="form-control autocomplete_txt" type='text'  id='GST_1' name='GST[]' disabled/> </td>
              <td><input class="form-control autocomplete_txt ttax" type='text'  id='TAX_1' name='TAX[]' disabled/> </td>
              <td><input class="form-control qty" type='number'  id='qty_1' name='qty[]' value="0" /> </td>
              <td><input class="form-control autocomplete_txt ttotal" type='text'  id='total_1' name='total[]'/> </td>
            </tr>
          </table>
          <a href="{{ url('/home') }}" class="btn btn-danger">Cancel</a>
          <button type="submit" class="btn btn-primary">Create Inovice</button>
          <button type="reset" class="btn btn-primary">Reset</button>
          <button type="button" class='btn btn-danger delete'>- Delete</button>
          <button type="button" class='btn btn-success addbtn'>+ Add More</button>
           <div class="float-right">
            Discount :   <input type="number"   id="discount" name="discount"  value="0" class="spc">&nbsp; 
            total tax :   <input type="number"   id="ttax" name="ttax" placeholder="Total Tax" disabled>&nbsp;
            Sub_total : <input type="number"   id="ttotal" name="ttotal" placeholder="Total payable amount" disabled>
          </div>
      </form>
    </div>
    <script type="text/javascript">
     $(".delete").on('click', function() {
      $('.chkbox:checkbox:checked').parents("tr").remove();
      $('.check_all').prop("checked", false); 
      updateSerialNo();
    });
    var i=$('table tr').length;
    $(".addbtn").on('click',function(){
      count=$('table tr').length;
      
      var data="<tr><td><input type='checkbox' class='chkbox'/></td>";
          data+="<td><span id='sn"+i+"'>"+count+".</span></td>";
          data+="<td><input class='form-control autocomplete_txt' type='text' data-type='productCode' id='productCode_"+i+"' name='productCode[]'/></td>";
          data+="<td><input class='form-control autocomplete_txt' type='text' data-type='productName' id='productName_"+i+"' name='productName[]'/></td>";
          data+="<td><input class='form-control autocomplete_txt' type='text'  id='price_"+i+"' name='price[]'/ disabled></td>";
          data+="<td><input class='form-control autocomplete_txt' type='text' id='HSN_"+i+"' name='HSN[]' disabled /></td>";     
          data+="<td><input class='form-control autocomplete_txt' type='text'  id='GST_"+i+"' name='GST[]' disabled/></td>";
          data+="<td><input class='form-control autocomplete_txt ttax' type='text'  id='TAX_"+i+"' name='TAX[]' disabled/></td>";
          data+="<td><input class='form-control qty' type='number' id='qty_"+i+"' name='qty[]' value='0' /></td>";
          // data+="<td><input class='form-control autocomplete_txt' type='text' id='Discount' name='Discount[]' value='0'/></td>";
          data+="<td><input class='form-control autocomplete_txt ttotal' type='text' id='total_"+i+"' name='total[]'/></td></tr>";
      $('table').append(data);
      i++;
    });
            

    function select_all() {
      $('input[class=chkbox]:checkbox').each(function(){ 
        if($('input[class=check_all]:checkbox:checked').length == 0){ 
          $(this).prop("checked", false); 
        } else {
          $(this).prop("checked", true); 
        } 
      });
    }
    function updateSerialNo(){
      obj=$('table tr').find('span');
      $.each( obj, function( key, value ) {
        id=value.id;
        $('#'+id).html(key+1);
      });
    }
    //autocomplete script
    $(document).on('focus','.autocomplete_txt',function(){
      type = $(this).data('type');
      
      if(type =='productCode' )autoType='product_code'; 
      if(type =='productName' )autoType='product_name'; 
      
       $(this).autocomplete({
           minLength: 0,
           source: function( request, response ) {
                $.ajax({
                    url: "{{ route('searchajax') }}",
                    dataType: "json",
                    data: {
                        term : request.term,
                        type : type,
                    },
                    success: function(data) {
                        var array = $.map(data, function (item) {
                           return {
                               label: item[autoType],
                               value: item[autoType],
                               data : item
                           }
                       });
                        response(array)
                    }
                });
           },
           select: function( event, ui ) {
               var data = ui.item.data;           
               id_arr = $(this).attr('id');
               id = id_arr.split("_");
               elementId = id[id.length-1];
               $('#productCode_'+elementId).val(data.product_code);
               $('#productName_'+elementId).val(data.product_name);
               $('#price_'+elementId).val(data.price);
               $('#HSN_'+elementId).val(data.HSN); 
               $('#GST_'+elementId).val(data.PGST);
               $('#TAX_'+elementId).val(data.TAX);
               $("#qty_"+elementId).change(function(){
                    var qty = $('#qty_'+elementId).val();
                    $('#total_'+elementId).val(data.total*qty);

             });  
             //------------------------------------------------
             $(".ttax").each(function() {
              $('#qty_'+elementId).focus(function() {
                  calculateTax();
                });
            }); 
            function calculateTax() {
            var sum = 0;
            $(".ttax").each(function() {
                    sum += parseFloat(this.value);
            });
            $("#ttax").val(sum);
        }
          //--------------------------------------------------
              $(".ttotal").each(function() {
              $('#qty_'+elementId).change(function() {
                  calculateTotal();
                });
            }); 
            function calculateTotal() {
            var sum = 0;
            $(".ttotal").each(function() {
                    sum += parseFloat(this.value);
            });
            $("#ttotal").val(sum);
        }
        // -----------------------------------------------------------
              $("#discount").change(function() {
                  calculateTotalWd();
                }); 
            function calculateTotalWd() {
                var discount =  $('#discount').val();
                var ttotal =  $('#ttotal').val();
                var final = ttotal - discount ; 
                $("#ttotal").val(final);
        }
        // ---------------------------------------------------------------
           }
       });
    });

    </script>    
    </body>
    </html>