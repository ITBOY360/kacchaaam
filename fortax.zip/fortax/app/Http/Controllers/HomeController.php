<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       if(Auth::user()->role->name == 'Client'){
        return view('Client.Client');
       }elseif(Auth::user()->role->name == 'Rocket'){
        return view('Rocket.ROcket');
       }elseif(Auth::user()->role->name == 'Crawler'){
        return view('Crawler.Crawler');
       }elseif(Auth::user()->role->name == 'Admin'){
        return view('Admin.Admin');
       }
    }
}
