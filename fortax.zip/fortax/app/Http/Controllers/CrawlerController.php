<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use Auth;
use Session;
use App\User;

class CrawlerController extends Controller
{
    public function addClient(Request $request){
       if(Auth::user()->role->name == 'Crawler'){
        if($request->isMethod('post')){
        $data = $request->all();
        $User = new User;
        $User->fname = $data['fname'];
        $User->lname = $data['lname'];
        $User->Mobile_number = $data['Mobile_number'];
        $User->email = $data['email'];
        $User->password = Hash::make($data['password']);
        $User->Account_number = $data['Account_number'];
        $User->aadhar = $data['aadhar'];
        $User->PAN = $data['PAN'];
        $User->Bussiness_name = $data['Bussiness_name'];
        $User->UserName_gst = $data['UserName_gst'];
        $User->Password_gst = $data['Password_gst']; 
        $User->GST = $data['GST'];
        $User->zone = $data['zone'];
        $User->state = $data['state'];
        $User->Address = $data['Address'];
        $User->refral_id = $data['refral_id'];
        $User->role_id = '1';

            // $User = json_decode(json_encode($data));
            // echo "<pre>";print_r($data);die;
            $User->save();
            return redirect('/Crawler/viewClient')->with('flash_message_success','Client  added successful');
      } 
    return view('Crawler.addClient');
  }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }

}

     public function viewClient(Request $request){
      if(Auth::user()->role->name == 'Crawler'){
      $refral_id = Auth::user()->email;
      $Client = User::where(['refral_id'=> $refral_id])->get();     
      return view('Crawler.viewClient')->with(compact('Client'));
   }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
 }

//     public function deleteClient($id = null){
//     if(Auth::user()->role->name == 'Crawler'){
//       if(!empty($id)){
//         User::where(['id'=>$id])->delete();
//         return redirect()->back()->with('flash_message_success','Client deleated successfully');
//       }
//   }else{
//         return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
//     }
// }

      public function editClient(Request $request,$id){
       if(Auth::user()->role->name == 'Crawler'){
        if($request->isMethod('post')){
          $data = $request->all();
          User::where(['id'=>$id])->update([
                        'fname' => $data['fname'],
                        'lname' => $data['lname'],
                        'Mobile_number' => $data['Mobile_number'],
                        'email' => $data['email'],
                        'password' => Hash::make($data['password']),
                        'Account_number' => $data['Account_number'],
                        'aadhar' => $data['aadhar'],
                        'PAN' => $data['PAN'],
                        'Bussiness_name' => $data['Bussiness_name'],
                        'UserName_gst' => $data['UserName_gst'],
                        'Password_gst' => $data['Password_gst'], 
                        'GST' => $data['GST'],
                        'zone' => $data['zone'],
                        'state' => $data['state'],
                        'Address' => $data['Address'],
                    ]);
            // $User = json_decode(json_encode($data));
            // echo "<pre>";print_r($data);die;
        return redirect('/Crawler/viewClient')->with('flash_message_success','Crawler  update successful');
      }
      $ClientDetails = User::where(['id'=>$id])->first(); 
      return view('Crawler.editClient')->with(compact('ClientDetails'));
    }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
  }
}
