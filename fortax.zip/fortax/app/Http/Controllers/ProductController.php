<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Auth;
use Session;
use App\Product;
use App\User;

class ProductController extends Controller
{
    public function addProduct(Request $request){
       if(Auth::user()->role->name == 'Client'){
    		if($request->isMethod('post')){
            $data = $request->all();
            $product = new Product;
            $product->client_id = $data['client_id'];
            $product->product_code = $data['product_code'];
            $product->product_name = $data['product_name'];
            $product->purchase_amt = $data['purchase_amt'];
            $product->sales_amt = $data['sales_amt'];
            $product->stock_qty = $data['stock_qty'];
            $product->HSN = $data['HSN'];
            $product->GST = $data['GST'];
            // $product = json_decode(json_encode($product));
            // echo "<pre>";print_r($product);die;
            $product->save();
            return redirect('/home/viewProduct')->with('flash_message_success','product  added successful');
   		}	
    	return view('Client.addProduct');
    }else{
       return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
  }

    public function viewProduct(Request $request){
      if(Auth::user()->role->name == 'Client'){
    	$email = Auth::user()->email;
    	$product = Product::where(['client_id'=>$email])->get();   	
   		return view('Client.viewProduct')->with(compact('product'));
   }else{
       return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
 }

    public function deleteProduct($id = null){
    if(Auth::user()->role->name == 'Client'){
   	if(!empty($id)){
   		Product::where(['id'=>$id])->delete();
   		return redirect()->back()->with('flash_message_success','product  deleated successfully');
   	}
  }else{
       return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
}

   public function editproduct(Request $request,$id){
    if(Auth::user()->role->name == 'Client'){
    	if($request->isMethod('post')){
    		$data = $request->all();
    		product::where(['id'=>$id])->update([
   									'product_code'=>$data['product_code'],
   									'product_name'=>$data['product_name'],
   									'purchase_amt'=>$data['purchase_amt'],
   									'sales_amt'=>$data['sales_amt'],
   									'stock_qty'=>$data['stock_qty'],
   									'HSN'=>$data['HSN'],
   									'GST'=>$data['GST']
   								]);
    		return redirect('/home/viewProduct')->with('flash_message_success','product  update successful');
    	}
   		$productDetails = Product::where(['id'=>$id])->first(); 
   		return view('Client.editProduct')->with(compact('productDetails'));
   		
   	}else{
       return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
   }
  }  
// ------------------------------------------------------------------------------------------------------------------
