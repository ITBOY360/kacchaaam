<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Auth;
use Session;
use App\Product;
use App\User;


class invoiceController extends Controller
{
     public function createBill(Request $request){
      if(Auth::user()->role->name == 'Client'){
        $email = Auth::user()->email;
        $product = Product::where(['client_id'=>$email])->get();
        // $product =json_decode(json_encode($product));
        // echo "<pre>";print_r($product);die;   
      return view('Client.CreateBill')->with(compact('product'));

     }else{
         return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
      }
   }

    public function searchResponse(Request $request){
        $query = $request->get('term','');
        $products=\DB::table('products');
        if($request->type=='productCode'){
            $products->where('product_code','LIKE','%'.$query.'%');
        }
        if($request->type=='productName'){
            $products->where('product_name','LIKE','%'.$query.'%');
        }
           $products=$products->get();  
        $data=array();
        foreach ($products as $product) {
        		$GST = $product->GST;
        		$purchase_amt = $product->purchase_amt;
        		$sales_amt =  $product->sales_amt;
        		$PGST = (($GST*100)/$purchase_amt);
        		$TAX = (($sales_amt*$PGST)/100);
        		$total = ($sales_amt+$TAX);
                $data[]=array('product_code'=>$product->product_code,'product_name'=>$product->product_name,'price'=>$product->sales_amt,'HSN'=>$product->HSN,'PGST'=>$PGST,'TAX'=>$TAX,'total'=>$total);
                $data = json_decode(json_encode($data));
        }
        if(count($data))
             return $data;
        else
            return ['product_code'=>'','product_name'=>'','price'=>'','HSN'=>'','PGST'=>'','TAX'=>$TAX,'total'=>''];
    }
}
