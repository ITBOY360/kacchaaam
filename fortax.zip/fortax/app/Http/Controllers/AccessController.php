<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AccessController extends Controller
{
    public function logout(){
    	Session()->flush();
        return redirect('/login')->with('flash_message_success','you are logged out !! login again  to continue');
    }
}
