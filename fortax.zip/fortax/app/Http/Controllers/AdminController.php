<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use Auth;
use Session;
use App\User;

class AdminController extends Controller
{
 // -----------------------------------------------Crawler Controll--------------------------------------------------------
 	public function addCrawler(Request $request){
    if(Auth::user()->role->name == 'Admin'){
    		if($request->isMethod('post') ){
        $data = $request->all();
        $User = new User;
        $User->fname = $data['fname'];
        $User->lname = $data['lname'];
  			$User->Mobile_number = $data['Mobile_number'];
  			$User->email = $data['email'];
  			$User->password = Hash::make($data['password']);
  			$User->Account_number = $data['Account_number'];
  			$User->aadhar = $data['aadhar'];
  			$User->PAN = $data['PAN'];
  			$User->Bussiness_name = $data['Bussiness_name'];
  			$User->zone = $data['zone'];
  			$User->state = $data['state'];
  			$User->Address = $data['Address'];
  			$User->refral_id = $data['refral_id'];
  			$User->role_id = '3';

            // $product = json_decode(json_encode($data));
            // echo "<pre>";print_r($data);die;
            $User->save();
            return redirect('/home/viewCrawler')->with('flash_message_success','Crawler  added successful');
   		}	
 		return view('Admin.addCrawler');
 }else{
  return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
 }
}

 	 public function viewCrawler(Request $request){
     if(Auth::user()->role->name == 'Admin'){
    	$role_id = '3';
    	$Crawler = User::where(['role_id'=>$role_id])->get();   	
   		return view('Admin.viewCrawler')->with(compact('Crawler'));
   }else{
      return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
   }
 }

   public function deleteCrawler($id = null){
   if(Auth::user()->role->name == 'Admin'){
   	if(!empty($id)){
   		User::where(['id'=>$id])->delete();
   		return redirect()->back()->with('flash_message_success','Crawler deleated successfully');
   	}
  }else{
      return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");

  }
}

    public function editCrawler(Request $request,$id){
     if(Auth::user()->role->name == 'Admin'){
      if($request->isMethod('post')){
        $data = $request->all();
        User::where(['id'=>$id])->update([
                  'fname'=>$data['fname'],
                  'lname'=>$data['lname'],
                  'Mobile_number'=>$data['Mobile_number'],
                  'email'=>$data['email'],
                  'password'=>Hash::make($data['password']),
                  'Account_number' => $data['Account_number'],
                  'aadhar' => $data['aadhar'],
                  'PAN' => $data['PAN'],
                  'Bussiness_name' => $data['Bussiness_name'],
                  'zone' => $data['zone'],
                  'state' => $data['state'],
                  'Address' => $data['Address']
                  ]);
        return redirect('/home/viewCrawler')->with('flash_message_success','Crawler  update successful');
      }
      $CrawlerDetails = User::where(['id'=>$id])->first(); 
      return view('Admin.editCrawler')->with(compact('CrawlerDetails'));
    }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
  }


    // --------------------------------------------------Rocket-----------------------------------------------------------------

      public function addRocket(Request $request){
       if(Auth::user()->role->name == 'Admin'){
        if($request->isMethod('post')){
        $data = $request->all();
        $User = new User;
        $User->fname = $data['fname'];
        $User->lname = $data['lname'];
        $User->Mobile_number = $data['Mobile_number'];
        $User->email = $data['email'];
        $User->password = Hash::make($data['password']);
        $User->Account_number = $data['Account_number'];
        $User->aadhar = $data['aadhar'];
        $User->PAN = $data['PAN'];
        $User->Address = $data['Address'];
        $User->refral_id = $data['refral_id'];
        $User->role_id = '2';

            // $User = json_decode(json_encode($data));
            // echo "<pre>";print_r($data);die;
            $User->save();
            return redirect('/home/viewRocket')->with('flash_message_success','Rocket  added successful');
      } 
    return view('Admin.addRocket');
  }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
}

     public function viewRocket(Request $request){
      if(Auth::user()->role->name == 'Admin'){
        $role_id = '2';
        $Rocket = User::where(['role_id'=>$role_id])->get();     
        return view('Admin.viewRocket')->with(compact('Rocket'));
   }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
 }

    public function deleteRocket($id = null){
    if(Auth::user()->role->name == 'Admin'){
    if(!empty($id)){
      User::where(['id'=>$id])->delete();
      return redirect()->back()->with('flash_message_success','Rocket deleated successfully');
    }
  }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
 }

   public function editRocket(Request $request,$id){
    if(Auth::user()->role->name == 'Admin'){
      if($request->isMethod('post')){
        $data = $request->all();
        User::where(['id'=>$id])->update([
                    'fname' => $data['fname'],
                    'lname' => $data['lname'],
                    'Mobile_number' => $data['Mobile_number'],
                    'email' => $data['email'],
                    'password' => Hash::make($data['password']),
                    'Account_number' => $data['Account_number'],
                    'aadhar' => $data['aadhar'],
                    'PAN' => $data['PAN'],
                    'Address' => $data['Address']
                  ]);
        return redirect('/home/viewRocket')->with('flash_message_success','product  update successful');
      }
      $RocketDetails = User::where(['id'=>$id])->first(); 
      return view('Admin.editRocket')->with(compact('RocketDetails'));
    }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
  }
// -------------------------------------------------client----------------------------------------------------------

     public function addClient(Request $request){
       if(Auth::user()->role->name == 'Admin'){
        if($request->isMethod('post')){
        $data = $request->all();
        $User = new User;
        $User->fname = $data['fname'];
        $User->lname = $data['lname'];
        $User->Mobile_number = $data['Mobile_number'];
        $User->email = $data['email'];
        $User->password = Hash::make($data['password']);
        $User->Account_number = $data['Account_number'];
        $User->aadhar = $data['aadhar'];
        $User->PAN = $data['PAN'];
        $User->Bussiness_name = $data['Bussiness_name'];
        $User->UserName_gst = $data['UserName_gst'];
        $User->Password_gst = $data['Password_gst']; 
        $User->GST = $data['GST'];
        $User->zone = $data['zone'];
        $User->state = $data['state'];
        $User->Address = $data['Address'];
        $User->refral_id = $data['refral_id'];
        $User->role_id = '1';

            // $User = json_decode(json_encode($data));
            // echo "<pre>";print_r($data);die;
            $User->save();
            return redirect('/home/viewClient')->with('flash_message_success','Client  added successful');
      } 
    return view('Admin.addClient');
  }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }

}

     public function viewClient(Request $request){
      if(Auth::user()->role->name == 'Admin'){
      $role_id = '1';
      $Client = User::where(['role_id'=>$role_id])->get();     
      return view('Admin.viewClient')->with(compact('Client'));
   }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
 }

    public function deleteClient($id = null){
    if(Auth::user()->role->name == 'Admin'){
      if(!empty($id)){
        User::where(['id'=>$id])->delete();
        return redirect()->back()->with('flash_message_success','Client deleated successfully');
      }
  }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
}

      public function editClient(Request $request,$id){
       if(Auth::user()->role->name == 'Admin'){
        if($request->isMethod('post')){
          $data = $request->all();
          User::where(['id'=>$id])->update([
                        'fname' => $data['fname'],
                        'lname' => $data['lname'],
                        'Mobile_number' => $data['Mobile_number'],
                        'email' => $data['email'],
                        'password' => Hash::make($data['password']),
                        'Account_number' => $data['Account_number'],
                        'aadhar' => $data['aadhar'],
                        'PAN' => $data['PAN'],
                        'Bussiness_name' => $data['Bussiness_name'],
                        'UserName_gst' => $data['UserName_gst'],
                        'Password_gst' => $data['Password_gst'], 
                        'GST' => $data['GST'],
                        'zone' => $data['zone'],
                        'state' => $data['state'],
                        'Address' => $data['Address'],
                    ]);
            // $User = json_decode(json_encode($data));
            // echo "<pre>";print_r($data);die;
        return redirect('/Admin/viewClient')->with('flash_message_success','Client  update successful');
      }
      $ClientDetails = User::where(['id'=>$id])->first(); 
      return view('Admin.editClient')->with(compact('ClientDetails'));
    }else{
        return redirect()->back()->with("flash_message_error","Aah !! don't act smart !! you are not allowed in this room");
    }
  }


// ------------------------------------------------------------------------------------------------------------------------------
}
