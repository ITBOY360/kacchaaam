<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('fname');
            $table->string('lname');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('aadhar');
            $table->string('PAN');
            $table->string('GST');
            $table->string('Bussiness_name');
            $table->integer('Account_number');
            $table->integer('Mobile_number');
            $table->text('Address');
            $table->integer('Status');
            $table->integer('role_id');
            $table->string('UserName_gst');
            $table->string('Password_gst');
            $table->string('zone');
            $table->string('state');
            $table->string('refral_id');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
