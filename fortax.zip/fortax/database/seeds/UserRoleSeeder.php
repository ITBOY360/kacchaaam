<?php

use Illuminate\Database\Seeder;

class UserRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role_Client = new App\Role; //client role
        $role_Rocket = new App\Role; //Computer at the server end to compute the gst manually
        $role_Crawler = new App\Role; //the one who work in mud.
        $role_Master = new App\Role; //father of all the bitches.

        $role_Client->name="Client";
        $role_Client->save();

        $role_Rocket->name="Rocket";
        $role_Rocket->save();

        $role_Crawler->name="Crawler";
        $role_Crawler->save();

        $role_Master->name="SuperAdmin";
        $role_Master->save();
    }
}
