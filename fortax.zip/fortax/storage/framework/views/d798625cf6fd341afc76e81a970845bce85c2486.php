<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-responsive.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/uniform.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/select2.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/fullcalendar.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/matrix-style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/matrix-media.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/jquery.gritter.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('fonts/css/font-awesome.css')); ?>" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link href='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css' rel='stylesheet' type='text/css'>
<style>
b{
	text-align: center;
}
</style>
</head>
<body>

<?php echo $__env->make('layouts.Crawler_layout.Crawler_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.Crawler_layout.Crawler_sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layouts.Crawler_layout.Crawler_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script> 
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script> 
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.validate.js')); ?>"></script> 
<script src="<?php echo e(asset('js/matrix.js')); ?>"></script> 
<script src="<?php echo e(asset('js/matrix.form_validation.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.popover.js')); ?>"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script> 

</script>
</body>
</html>
