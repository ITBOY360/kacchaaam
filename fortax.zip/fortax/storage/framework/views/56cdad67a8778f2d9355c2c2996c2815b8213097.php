<?php $__env->startSection('title','View Rocket'); ?>
<?php $__env->startSection('content'); ?>


<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?php echo e(url('/home')); ?>" title="Go to Home" class="tip-bottom">
      <i class="icon-home"></i> Home</a> <a href="#" class="current">Rocket</a> </div>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <h3>Avilable Rockets</h3><hr>
        <?php if(Session::has('flash_message_success')): ?>
          <div class="alert alert-success alert-dismissible animated shake">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <b><?php echo Session('flash_message_success'); ?> </b>
          </div>        
        <?php endif; ?> 
        <div class="widget-box"> 
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <a href="<?php echo e(url('/home/addRocket')); ?>" class="btn btn-success pull-right">Add more Rocket</a>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered  data-table" id="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Mobile Number</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>ACtion</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $Rocket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td><b><?php echo e($key->fname); ?> <?php echo e($key->lname); ?></b></td>
                  <td><b><?php echo e($key->Mobile_number); ?></b></td>
                  <td><b><?php echo e($key->email); ?></b></td>
                  <td><b><?php echo e($key->Address); ?></b></td>

                  <td class="center">
                    <a href="#view<?php echo e($key->id); ?>" data-toggle="modal"  class="btn btn-success btn-mini">View</a>
                    <a href="<?php echo e(url('/home/editRocket/'.$key->id )); ?>" class="btn btn-primary btn-mini">Edit</a>
                    <a  rel="<?php echo e($key->id); ?>"  rel1="deleteRocket" href="javascript: " class="deleteRecord btn btn-danger btn-mini">Delete</a>
                  </td> 
                </tr>
                 <div id="view<?php echo e($key->id); ?>" class="modal hide animated bounce ">
                      <div class="modal-header">
                        <button data-dismiss="modal" class="close" type="button">×</button>
                        <h3><?php echo e($key->fname); ?> <?php echo e($key->lname); ?> Compleate Details</h3>
                      </div>
                      <div class="modal-body">
                        <div class="container-fluid">
                          <div class="row-fluid">
                      <div class="span6 pull-left">              
                             <ul>
                                <li><strong>Name</strong></li>
                                <li><strong>Mobile Number</strong></li>
                                <li><strong>Email</strong></li>
                                <li><strong>Address</strong></li>
                                <li><strong>Bank A/C number</strong></li>
                                <li><strong>Aadhar Number</strong></li> 
                                <li><strong>PAN</strong></li>
                              </ul>
                            </div>
                        <div class="span6 pull-right">              
                             <ul>
                                <li class="red"><?php echo e($key->fname); ?> <?php echo e($key->lname); ?></li>
                                <li class="red"><?php echo e($key->Mobile_number); ?></li>
                                <li class="red"><?php echo e($key->email); ?></li>
                                <li class="red"><?php echo e($key->Address); ?></li>
                                <li class="red"><?php echo e($key->Account_number); ?></li>
                                <li class="red"><?php echo e($key->aadhar); ?></li>
                                <li class="red"><?php echo e($key->PAN); ?></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
        
      </div>
    </div>       
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin_layout.admin_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>