<!--sidebar-menu-->
<div id="sidebar"><a href="<?php echo e(url('/home')); ?>" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="<?php echo e(url('/home')); ?>"><i class="icon  icon-dashboard"></i> <span>Dashboard</span></a> </li>
    <li><a href="<?php echo e(url('/home/createBill')); ?>"><i class="icon icon-arrow-up"></i><span>Create Bill</span></a> </li>
    <li><a href="<?php echo e(url('/home/addProduct')); ?>"><i class="icon icon-plus"></i><span>Add Product</span></a> </li>
    <li><a href="<?php echo e(url('/home/viewProduct')); ?>"><i class="icon icon-list"></i><span>List Product</span></a> </li>
    <li><a href="<?php echo e(url('/home/viewSales')); ?>"><i class="icon icon-bar-chart"></i><span>View Sales</span></a> </li>
   
  </ul>
</div>
<!--sidebar-menu--> 