<?php $__env->startSection('title','Add Rocket'); ?>
<?php $__env->startSection('content'); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?php echo e(url('/home')); ?>" title="Go to Home" class="tip-bottom">
    	<i class="icon-home"></i> Home</a> <a href="<?php echo e(url('/home/viewRocket')); ?>">Rocket</a> <a href="#" class="current">add Rocket</a> </div>
  </div>
  <div class="container-fluid">    
    <hr>
       <?php if(Session::has('flash_message_success')): ?>
                    <div class="alert alert-success alert-dismissible animated shake">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                       <b><?php echo Session('flash_message_success'); ?> </b>
                    </div>        
            <?php endif; ?>

          <?php if(Session::has('flash_message_error')): ?>
                    <div class="alert alert-danger alert-dismissible animated shake">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                       <b><?php echo Session('flash_message_error'); ?> </b>
                    </div>        
            <?php endif; ?>     
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
            <h5>Add Rocket</h5>
          </div>
          <div class="widget-content nopadding">
            <form class="form-horizontal" method="post" action="<?php echo e(url('/home/addRocket')); ?>" name="addRocket" id="addRocket" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="refral_id" id="refral_id" value="Admin">
              <div class="control-group">
                <label class="control-label">First Name</label>
                <div class="controls">
                  <input type="text" name="fname" id="fname" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Last Name</label>
                <div class="controls">
                  <input type="text" name="lname" id="lname" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Mobile Number</label>
                <div class="controls">
                  <input type="number" name="Mobile_number" id="Mobile_number" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">EMail</label>
                <div class="controls">
                  <input type="email" name="email" id="email" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Password</label>
                <div class="controls">
                  <input type="password" name="password" id="password" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Bank Account Number</label>
                <div class="controls">
                  <input type="number" name="Account_number" id="Account_number" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Aadhar Number</label>
                <div class="controls">
                  <input type="number" name="aadhar" id="aadhar" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">PAN</label>
                <div class="controls">
                  <input type="text" name="PAN" id="PAN" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Address</label>
                <div class="controls">
                  <textarea name="Address" id="Address" required></textarea>
                </div>
              </div>
              <div class="form-actions">
                <input type="submit" value="add Rocket" class="btn btn-success">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin_layout.admin_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>