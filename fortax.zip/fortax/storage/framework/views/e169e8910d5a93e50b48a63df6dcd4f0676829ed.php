<!--sidebar-menu-->
<div id="sidebar"><a href="<?php echo e(url('/home')); ?>" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="<?php echo e(url('/home')); ?>"><i class="icon  icon-dashboard"></i> <span>Dashboard</span></a> </li>
    <li><a href="<?php echo e(url('/Crawler/addClient')); ?>"><i class="icon icon-plus"></i><span>Add Client</span></a> </li>
    <li><a href="<?php echo e(url('/Crawler/viewClient')); ?>"><i class="icon icon-list"></i><span>View Client</span></a> </li>
   
  </ul>
</div>
<!--sidebar-menu--> 