<?php $__env->startSection('title','View Product'); ?>
<?php $__env->startSection('content'); ?>


<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?php echo e(url('/home')); ?>" title="Go to Home" class="tip-bottom">
      <i class="icon-home"></i> Home</a> <a href="#" class="current">product</a> </div>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <h3>Avilable product in Shop</h3><hr>
        <?php if(Session::has('flash_message_success')): ?>
          <div class="alert alert-success alert-dismissible animated shake">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <b class="centertxt"><?php echo Session('flash_message_success'); ?> </b>
          </div>        
        <?php endif; ?> 
        <div class="widget-box"> 
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <a href="<?php echo e(url('/home/addProduct')); ?>" class="btn btn-success pull-right">Add more product</a>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered  data-table" id="data-table">
              <thead>
                <tr>
                  <th>Product code</th>
                  <th>Product Name</th>
                  <th>Purchase Amount</th>
                  <th>Sales Amount</th>
                  <th>Stock Quantity</th>
                  <th>HSN</th>
                  <th>GST</th>
                  <th>ACtion</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td><b class="centertxt"><?php echo e($key->product_code); ?></b></td>
                  <td><b class="centertxt"><?php echo e($key->product_name); ?></b></td>
                  <td><b class="centertxt"><?php echo e($key->purchase_amt); ?> Rs</b></td>
                  <td><b class="centertxt"><?php echo e($key->sales_amt); ?> Rs</b></td>
                  <td><b class="centertxt"><?php echo e($key->Stock_qty); ?></b></td>
                  <td><b class="centertxt"><?php echo e($key->HSN); ?> <b></b></b></td>
                   <td><b class="centertxt"><?php echo e($key->GST); ?> <b>Rs</b></b></td>
                  <td class="center">
                    <a href="<?php echo e(url('/home/editProduct/'.$key->id )); ?>" class="btn btn-primary btn-mini">Edit</a>
                    <a  rel="<?php echo e($key->id); ?>"  rel1="deleteProduct" href="javascript: " class="deleteRecord btn btn-danger btn-mini">Delete</a>
                  </td> 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>       
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Client_layout.client_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>