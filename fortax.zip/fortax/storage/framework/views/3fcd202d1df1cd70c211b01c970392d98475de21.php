<!--sidebar-menu-->
<div id="sidebar"><a href="<?php echo e(url('/home')); ?>" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="<?php echo e(url('/home')); ?>"><i class="icon  icon-dashboard"></i> <span>Dashboard</span></a> 
      <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Crawler</span> 
      	<span class="label label-important">2</span></a>
      <ul>
        <li><a href="<?php echo e(url('/home/addCrawler')); ?>">Add Crawler</a></li>
        <li><a href="<?php echo e(url('/home/viewCrawler')); ?>">View Crawler</a></li>
        
      </ul>
    </li>
     <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Rocket</span> 
      	<span class="label label-important">2</span></a>
      <ul>
        <li><a href="<?php echo e(url('/home/addRocket')); ?>">Add Rocket</a></li>
        <li><a href="<?php echo e(url('/home/viewRocket')); ?>">View Rocket</a></li>
        
      </ul>
    </li> 
      <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Client</span> 
      	<span class="label label-important">2</span></a>
      <ul>
        <li><a href="<?php echo e(url('/Admin/addClient')); ?>">Add Client</a></li>
        <li><a href="<?php echo e(url('/Admin/viewClient')); ?>">View Client</a></li>
        
      </ul>
    </li>
   
  </ul>
</div>
<!--sidebar-menu--> 