<?php $__env->startSection('title','Create Bill'); ?>
<?php $__env->startSection('content'); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?php echo e(url('/home')); ?>" title="Go to Home" class="tip-bottom">
    	<i class="icon-home"></i> Home</a> <a href="#" class="current">Create Bill</a> </div>
  </div>
  <div class="container-fluid">    
    <hr>
       <?php if(Session::has('flash_message_success')): ?>
                    <div class="alert alert-success alert-dismissible animated shake">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                       <b><?php echo Session('flash_message_success'); ?> </b>
                    </div>        
            <?php endif; ?>

          <?php if(Session::has('flash_message_error')): ?>
                    <div class="alert alert-danger alert-dismissible animated shake">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                       <b><?php echo Session('flash_message_error'); ?> </b>
                    </div>        
            <?php endif; ?>     
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
            <h5>Create Bill</h5>
          </div>
          <div class="widget-content nopadding">
            <form class="form-horizontal" method="post" action="<?php echo e(url('/home/addProduct')); ?>" name="addProduct" id="addProduct" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="client_id" id="client_id" value="<?php echo e(Auth::user()->email); ?>">
              <div class="control-group">
                <label class="control-label">Product Code</label>
                <div class="controls">
                  <input type="text" name="product_code" id="product_code" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Product Name</label>
                <div class="controls">
                  <input type="text" name="product_name" id="product_name" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Purchase Amount</label>
                <div class="controls">
                  <input type="text" name="purchase_amt" id="purchase_amt" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Sales Amount</label>
                <div class="controls">
                  <input type="text" name="sales_amt" id="sales_amt" required>
                </div>
              </div>

              <div class="control-group">
                <label class="control-label">Stock Quantity</label>
                <div class="controls">
                  <input type="text" name="stock_qty" id="stock_qty" required>
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">HSN CODE</label>
                <div class="controls">
                  <input type="text" name="HSN" id="HSN">
                </div>
              </div>

               <div class="control-group">
                <label class="control-label">Total GST paid</label>
                <div class="controls">
                  <input type="text" name="GST" id="GST" required>
                </div>
              </div>
              <div class="form-actions">
                <input type="submit" value="Create Bill" class="btn btn-success">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Client_layout.client_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>